INSERT INTO AGENT VALUES ('AG0001', 'Helen', 'Nichols', 44, 'F');

INSERT INTO AGENT VALUES ('AG0002', 'Antonio', 'Burton', 27, 'M');

INSERT INTO AGENT VALUES ('AG0003', 'Steve', 'Johnson', 49, 'M');

INSERT INTO AGENT VALUES ('AG0004', 'Bobby', 'Thomas', 57, 'M');

INSERT INTO AGENT VALUES ('AG0005', 'Scott', 'Brooks', 35, 'M');

INSERT INTO AGENT VALUES ('AG0006', 'Richard', 'Henry', 59, 'M');

INSERT INTO AGENT VALUES ('AG0007', 'Louis', 'Ramirez', 27, 'M');

INSERT INTO AGENT VALUES ('AG0008', 'Lawrence', 'Hall', 22, 'M');

INSERT INTO AGENT VALUES ('AG0009', 'Dennis', 'Hunter', 34, 'M');

INSERT INTO AGENT VALUES ('AG0010', 'Jerry', 'Bryant', 24, 'M');

INSERT INTO AGENT VALUES ('AG0011', 'Sean', 'Williamson', 50, 'M');

INSERT INTO AGENT VALUES ('AG0012', 'Brandon', 'Ramos', 34, 'M');

INSERT INTO AGENT VALUES ('AG0013', 'Patricia', 'Flores', 25, 'F');

INSERT INTO AGENT VALUES ('AG0014', 'Larry', 'Armstrong', 36, 'M');

INSERT INTO AGENT VALUES ('AG0015', 'Rebecca', 'Cole', 53, 'F');

INSERT INTO AGENT VALUES ('AG0016', 'Billy', 'Payne', 57, 'M');

INSERT INTO AGENT VALUES ('AG0017', 'Louise', 'Rice', 28, 'F');

INSERT INTO AGENT VALUES ('AG0018', 'Philip', 'Allen', 55, 'M');

INSERT INTO AGENT VALUES ('AG0019', 'Bonnie', 'Weaver', 35, 'F');

INSERT INTO AGENT VALUES ('AG0020', 'Mary', 'Greene', 37, 'F');

INSERT INTO AGENT VALUES ('AG0021', 'Joseph', 'Edwards', 59, 'M');

INSERT INTO AGENT VALUES ('AG0022', 'Kathy', 'Lopez', 50, 'F');

INSERT INTO AGENT VALUES ('AG0023', 'Roger', 'Ortiz', 22, 'M');

INSERT INTO AGENT VALUES ('AG0024', 'Aaron', 'Nelson', 25, 'M');

INSERT INTO AGENT VALUES ('AG0025', 'Paula', 'Payne', 43, 'F');
