INSERT INTO CONCERT values ('CN0001', 'Sing Me to Sleep',  'Nancy Robertson', '1630', '2000', '2016-04-16', 'TT0001');

INSERT INTO CONCERT values ('CN0002', 'My Way',  'Carlos Nelson', '1530', '1830', '2016-06-09', 'TT0002');

INSERT INTO CONCERT values ('CN0003', 'Faded',  'Jane Brown', '1520', '1820', '2016-11-08', 'TT0003');

INSERT INTO CONCERT values ('CN0004', 'Shuai Dao Fen Shou',  'James Chou', '2000', '2300', '2016-05-27', 'TT0004');

INSERT INTO CONCERT values ('CN0005', 'Chou Ba Guai',  'Alex Goh', '1600', '1850', '2016-12-10', 'TT0005');

INSERT INTO CONCERT values ('CN0006', 'Carnival Night 1617',  'Chris Too', '2340', '0200', '2016-04-28', 'TT0006');

INSERT INTO CONCERT values ('CN0007', 'Good For You',  'Kelly Armstrong', '1440', '2020', '2016-06-11', 'TT0007');

INSERT INTO CONCERT values ('CN0008', 'Cinta Mu',  'Siti John', '1100', '1520', '2016-05-21', 'TT0008');

INSERT INTO CONCERT values ('CN0009', 'Ice to Ice',  'Lorain Ng', '2100', '0000', '2016-05-31', 'TT0009');

INSERT INTO CONCERT values ('CN0010', 'Timeless',  'Patrick Stevens', '1120', '1600', '2016-02-11', 'TT0010');

INSERT INTO CONCERT values ('CN0011', 'Shake the World',  'Susan Bennett', '1400', '1700', '2016-04-20', 'TT0011');

INSERT INTO CONCERT values ('CN0012', 'Let Me Love You',  'Jane Dunn', '1300', '1800', '2016-12-29', 'TT0012');

INSERT INTO CONCERT values ('CN0013', 'Ni Hao Bu Hao',  'Eric Ng', '1300', '1800', '2016-08-06', 'TT0013');

INSERT INTO CONCERT values ('CN0014', 'Love, The Thing', 'Kathy Mcdonald', '1200', '1600', '2016-12-14', 'TT0014');

INSERT INTO CONCERT values ('CN0015', 'All Night', 'Janet Anderson', '2200', '0200', '2017-01-11', 'TT0015');

INSERT INTO CONCERT values ('CN0016', 'High Max', 'Sharon Perry', '1500', '2100', '2016-03-29', 'TT0016');

INSERT INTO CONCERT values ('CN0017', 'Rock the Night', 'Michael Roberts', '1500', '2000', '2016-11-07', 'TT0017');

INSERT INTO CONCERT values ('CN0018', 'We Are Young','Timothy Porter', '1730', '2100', '2016-08-15', 'TT0018');

INSERT INTO CONCERT values ('CN0019', 'Catch the Dream',  'June Day', '1100', '1630', '2016-02-23', 'TT0019');

INSERT INTO CONCERT values ('CN0020', 'Hands to Hands',  'Linda Sullivan', '1430', '1800', '2016-11-23', 'TT0020');

INSERT INTO CONCERT values ('CN0021', 'Never Alone','Lori Cunningham', '1400', '2000', '2017-01-02', 'TT0021');

INSERT INTO CONCERT values ('CN0022', 'Beat It', 'Jennifer Stanley', '1700', '2230', '2016-06-08', 'TT0022');

INSERT INTO CONCERT values ('CN0023', 'Demon Come',  'Angel Tan', '1730', '0000', '2016-08-09', 'TT0023');

INSERT INTO CONCERT values ('CN0024', 'Hello', 'Rebecca Foster', '1000', '1600', '2016-10-09', 'TT0024');

INSERT INTO CONCERT values ('CN0025', 'Music On!',  'Edward Sims', '1030', '1630', '2016-11-01', 'TT0025');
