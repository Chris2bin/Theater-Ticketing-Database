INSERT INTO CUSTOMER VALUES ('CS0001', 'Roger', 'Hunter', 58, 'M');

INSERT INTO CUSTOMER VALUES ('CS0002', 'Matthew', 'Taylor', 15, 'M');

INSERT INTO CUSTOMER VALUES ('CS0003', 'Roy', 'Montgomery', 72, 'M');

INSERT INTO CUSTOMER VALUES ('CS0004', 'Lillian', 'Hayes', 8, 'F');

INSERT INTO CUSTOMER VALUES ('CS0005', 'Rebecca', 'Washington', 19, 'F');

INSERT INTO CUSTOMER VALUES ('CS0006', 'Brian', 'Daniels', 80, 'M');

INSERT INTO CUSTOMER VALUES ('CS0007', 'Nancy', 'Reynolds', 10, 'F');

INSERT INTO CUSTOMER VALUES ('CS0008', 'Kimberly', 'Roberts', 25, 'F');

INSERT INTO CUSTOMER VALUES ('CS0009', 'Patricia', 'Bowman', 78, 'F');

INSERT INTO CUSTOMER VALUES ('CS0010', 'Lillian', 'Thomas', 27, 'F');

INSERT INTO CUSTOMER VALUES ('CS0011', 'Earl', 'Mcdonald', 28, 'M');

INSERT INTO CUSTOMER VALUES ('CS0012', 'Nicole', 'Fields', 15, 'F');

INSERT INTO CUSTOMER VALUES ('CS0013', 'Mildred', 'Williamson', 76, 'F');

INSERT INTO CUSTOMER VALUES ('CS0014', 'Pamela', 'Reid', 38, 'F');

INSERT INTO CUSTOMER VALUES ('CS0015', 'Andrew', 'Pierce', 16, 'M');

INSERT INTO CUSTOMER VALUES ('CS0016', 'Brian', 'Lewis', 53, 'M');

INSERT INTO CUSTOMER VALUES ('CS0017', 'Juan', 'Webb', 34, 'M');

INSERT INTO CUSTOMER VALUES ('CS0018', 'Jesse', 'Brooks', 76, 'M');

INSERT INTO CUSTOMER VALUES ('CS0019', 'Alan', 'Black', 35, 'M');

INSERT INTO CUSTOMER VALUES ('CS0020', 'Carlos', 'Collins', 76, 'M');

INSERT INTO CUSTOMER VALUES ('CS0021', 'Linda', 'Thomas', 40, 'F');

INSERT INTO CUSTOMER VALUES ('CS0022', 'Andrea', 'Day', 55, 'F');

INSERT INTO CUSTOMER VALUES ('CS0023', 'Julia', 'Gomez', 78, 'F');

INSERT INTO CUSTOMER VALUES ('CS0024', 'Christina', 'Pierce', 71, 'F');

INSERT INTO CUSTOMER VALUES ('CS0025', 'Heather', 'Hill', 26, 'F');

INSERT INTO CUSTOMER VALUES ('CS0026', 'Louis', 'Lawson', 37, 'M');

INSERT INTO CUSTOMER VALUES ('CS0027', 'William', 'Stevens', 62, 'M');

INSERT INTO CUSTOMER VALUES ('CS0028', 'Howard', 'Cox', 39, 'M');

INSERT INTO CUSTOMER VALUES ('CS0029', 'Kathleen', 'James', 29, 'F');

INSERT INTO CUSTOMER VALUES ('CS0030', 'Kevin', 'Kelley', 64, 'M');

INSERT INTO CUSTOMER VALUES ('CS0031', 'Antonio', 'Ramirez', 65, 'M');

INSERT INTO CUSTOMER VALUES ('CS0032', 'Emily', 'Meyer', 56, 'F');

INSERT INTO CUSTOMER VALUES ('CS0033', 'Ryan', 'Frazier', 22, 'M');

INSERT INTO CUSTOMER VALUES ('CS0034', 'Jean', 'Murphy', 31, 'F');

INSERT INTO CUSTOMER VALUES ('CS0035', 'Stephen', 'Harvey', 27, 'M');

INSERT INTO CUSTOMER VALUES ('CS0036', 'Wanda', 'Thomas', 38, 'F');

INSERT INTO CUSTOMER VALUES ('CS0037', 'Clarence', 'Fuller', 15, 'M');

INSERT INTO CUSTOMER VALUES ('CS0038', 'Ralph', 'Robinson', 14, 'M');

INSERT INTO CUSTOMER VALUES ('CS0039', 'Gregory', 'Grant', 37, 'M');

INSERT INTO CUSTOMER VALUES ('CS0040', 'Howard', 'Murray', 64, 'M');

INSERT INTO CUSTOMER VALUES ('CS0041', 'Janice', 'Bailey', 70, 'F');

INSERT INTO CUSTOMER VALUES ('CS0042', 'James', 'Stephens', 19, 'M');

INSERT INTO CUSTOMER VALUES ('CS0043', 'Frank', 'Williamson', 71, 'M');

INSERT INTO CUSTOMER VALUES ('CS0044', 'Billy', 'Howard', 31, 'M');

INSERT INTO CUSTOMER VALUES ('CS0045', 'Maria', 'Tucker', 16, 'F');

INSERT INTO CUSTOMER VALUES ('CS0046', 'Harold', 'Perry', 66, 'M');

INSERT INTO CUSTOMER VALUES ('CS0047', 'Kimberly', 'Bell', 32, 'F');

INSERT INTO CUSTOMER VALUES ('CS0048', 'Margaret', 'Fernandez', 9, 'F');

INSERT INTO CUSTOMER VALUES ('CS0049', 'Albert', 'Ryan', 34, 'M');

INSERT INTO CUSTOMER VALUES ('CS0050', 'John', 'Hayes', 11, 'M');

INSERT INTO CUSTOMER VALUES ('CS0051', 'Julie', 'Kelley', 59, 'F');

INSERT INTO CUSTOMER VALUES ('CS0052', 'Christina', 'Watson', 49, 'F');

INSERT INTO CUSTOMER VALUES ('CS0053', 'Adam', 'Armstrong', 17, 'M');

INSERT INTO CUSTOMER VALUES ('CS0054', 'Johnny', 'Elliott', 69, 'M');

INSERT INTO CUSTOMER VALUES ('CS0055', 'Lisa', 'Washington', 10, 'F');

INSERT INTO CUSTOMER VALUES ('CS0056', 'Robert', 'Ryan', 54, 'M');

INSERT INTO CUSTOMER VALUES ('CS0057', 'Jimmy', 'Hicks', 13, 'M');

INSERT INTO CUSTOMER VALUES ('CS0058', 'Kimberly', 'Crawford', 79, 'F');

INSERT INTO CUSTOMER VALUES ('CS0059', 'Sharon', 'Watkins', 15, 'F');

INSERT INTO CUSTOMER VALUES ('CS0060', 'Shawn', 'Hart', 68, 'M');

INSERT INTO CUSTOMER VALUES ('CS0061', 'Shirley', 'Robinson', 19, 'F');

INSERT INTO CUSTOMER VALUES ('CS0062', 'Arthur', 'Harvey', 56, 'M');

INSERT INTO CUSTOMER VALUES ('CS0063', 'John', 'Henry', 49, 'M');

INSERT INTO CUSTOMER VALUES ('CS0064', 'James', 'Bradley', 70, 'M');

INSERT INTO CUSTOMER VALUES ('CS0065', 'Kathleen', 'Murphy', 28, 'F');

INSERT INTO CUSTOMER VALUES ('CS0066', 'Laura', 'Franklin', 10, 'F');

INSERT INTO CUSTOMER VALUES ('CS0067', 'Jane', 'Torres', 18, 'F');

INSERT INTO CUSTOMER VALUES ('CS0068', 'Dennis', 'Moreno', 44, 'M');

INSERT INTO CUSTOMER VALUES ('CS0069', 'Denise', 'Warren', 35, 'F');

INSERT INTO CUSTOMER VALUES ('CS0070', 'Doris', 'Banks', 70, 'F');

INSERT INTO CUSTOMER VALUES ('CS0071', 'Sandra', 'Bell', 52, 'F');

INSERT INTO CUSTOMER VALUES ('CS0072', 'Thomas', 'Barnes', 60, 'M');

INSERT INTO CUSTOMER VALUES ('CS0073', 'Bruce', 'Smith', 10, 'M');

INSERT INTO CUSTOMER VALUES ('CS0074', 'Bonnie', 'Perez', 8, 'F');

INSERT INTO CUSTOMER VALUES ('CS0075', 'Donna', 'Lee', 59, 'F');

INSERT INTO CUSTOMER VALUES ('CS0076', 'Michael', 'Willis', 33, 'M');

INSERT INTO CUSTOMER VALUES ('CS0077', 'Peter', 'Moore', 35, 'M');

INSERT INTO CUSTOMER VALUES ('CS0078', 'Pamela', 'Davis', 21, 'F');

INSERT INTO CUSTOMER VALUES ('CS0079', 'Harold', 'Carter', 15, 'M');

INSERT INTO CUSTOMER VALUES ('CS0080', 'Diane', 'Cox', 23, 'F');

INSERT INTO CUSTOMER VALUES ('CS0081', 'Paula', 'Gonzales', 32, 'F');

INSERT INTO CUSTOMER VALUES ('CS0082', 'Jane', 'Bishop', 33, 'F');

INSERT INTO CUSTOMER VALUES ('CS0083', 'Joan', 'Sullivan', 34, 'F');

INSERT INTO CUSTOMER VALUES ('CS0084', 'Wanda', 'Smith', 39, 'F');

INSERT INTO CUSTOMER VALUES ('CS0085', 'Richard', 'Thomas', 25, 'M');

INSERT INTO CUSTOMER VALUES ('CS0086', 'Scott', 'Tucker', 28, 'M');

INSERT INTO CUSTOMER VALUES ('CS0087', 'Eugene', 'Davis', 63, 'M');

INSERT INTO CUSTOMER VALUES ('CS0088', 'Evelyn', 'Simmons', 65, 'F');

INSERT INTO CUSTOMER VALUES ('CS0089', 'Rose', 'Coleman', 8, 'F');

INSERT INTO CUSTOMER VALUES ('CS0090', 'Jessica', 'Ellis', 37, 'F');

INSERT INTO CUSTOMER VALUES ('CS0091', 'Gloria', 'Franklin', 55, 'F');

INSERT INTO CUSTOMER VALUES ('CS0092', 'John', 'Green', 63, 'M');

INSERT INTO CUSTOMER VALUES ('CS0093', 'Theresa', 'White', 78, 'F');

INSERT INTO CUSTOMER VALUES ('CS0094', 'Brandon', 'Martinez', 75, 'M');

INSERT INTO CUSTOMER VALUES ('CS0095', 'Matthew', 'Wells', 77, 'M');

INSERT INTO CUSTOMER VALUES ('CS0096', 'Julie', 'Stone', 31, 'F');

INSERT INTO CUSTOMER VALUES ('CS0097', 'Alan', 'Jones', 15, 'M');

INSERT INTO CUSTOMER VALUES ('CS0098', 'Frances', 'Mitchell', 48, 'F');

INSERT INTO CUSTOMER VALUES ('CS0099', 'Peter', 'Jones', 67, 'M');

INSERT INTO CUSTOMER VALUES ('CS0100', 'Lillian', 'Burke', 15, 'F');
