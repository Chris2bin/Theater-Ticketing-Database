﻿INSERT INTO THEATRE VALUES ('TT0001', 'Velingrad', 'Messerschmidt', 2640, 0.64, 6);

INSERT INTO THEATRE VALUES ('TT0002', 'Khudāydād Khēl', 'Continental', 1116, 0.75, 7);

INSERT INTO THEATRE VALUES ('TT0003', 'Beizi', 'Sullivan', 4352, 0.89, 5);

INSERT INTO THEATRE VALUES ('TT0004', 'Shchūchīnsk', 'Buell', 2785, 0.51, 7);

INSERT INTO THEATRE VALUES ('TT0005', 'Anshun', 'Heath', 902, 0.5, 5);

INSERT INTO THEATRE VALUES ('TT0006', 'Taganrog', 'Scofield', 1158, 0.81, 6);

INSERT INTO THEATRE VALUES ('TT0007', 'Yumani', 'Melby', 2643, 0.21, 5);

INSERT INTO THEATRE VALUES ('TT0008', 'Cáceres', 'Nobel', 1198, 0.65, 2);

INSERT INTO THEATRE VALUES ('TT0009', 'São Paulo de Olivença', 'Sunbrook', 2176, 0.48, 8);

INSERT INTO THEATRE VALUES ('TT0010', 'Tapon', 'Gina', 2252, 0.97, 8);

INSERT INTO THEATRE VALUES ('TT0011', 'Shalamzār', 'Sundown', 1252, 0.33, 3);

INSERT INTO THEATRE VALUES ('TT0012', 'Turpo', 'Algoma', 4333, 0.09, 8);

INSERT INTO THEATRE VALUES ('TT0013', 'Yeni Suraxanı', 'Boyd', 1624, 0.61, 4);

INSERT INTO THEATRE VALUES ('TT0014', 'Latowicz', 'Tennessee', 2588, 0.13, 3);

INSERT INTO THEATRE VALUES ('TT0015', 'Manturovo', 'Buena Vista', 1349, 0.13, 1);

INSERT INTO THEATRE VALUES ('TT0016', 'Santa Fe', 'Bultman', 3361, 0.09, 6);

INSERT INTO THEATRE VALUES ('TT0017', 'Lubbock', 'Grim', 3909, 0.79, 5);

INSERT INTO THEATRE VALUES ('TT0018', 'Xijiao', 'Charing Cross', 1634, 0.93, 3);

INSERT INTO THEATRE VALUES ('TT0019', 'Reggada', 'Sloan', 4015, 0.4, 1);

INSERT INTO THEATRE VALUES ('TT0020', 'Cabugao', 'American Ash', 1205, 0.91, 3);

INSERT INTO THEATRE VALUES ('TT0021', 'Saratak', 'Summerview', 1805, 0.31, 5);

INSERT INTO THEATRE VALUES ('TT0022', 'Zhifudao', 'Cambridge', 4179, 0.84, 7);

INSERT INTO THEATRE VALUES ('TT0023', 'Viçosa do Ceará', 'Manley', 2191, 0.02, 1);

INSERT INTO THEATRE VALUES ('TT0024', 'Lárdos', 'Amoth', 2176, 0.68, 6);

INSERT INTO THEATRE VALUES ('TT0025', 'Ng Jing Keong', 'Monument', 4281, 0.74, 8);
